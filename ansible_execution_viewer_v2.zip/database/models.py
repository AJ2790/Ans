from sqlalchemy.orm import DeclarativeBase
from sqlalchemy import *
class Base(DeclarativeBase): pass
class TaskEvent(Base):
 __tablename__="task_events"
 id=Column(Integer,primary_key=True)
 event_id=Column(Integer,index=True)
 job_id=Column(Integer,index=True)
 host=Column(String,index=True)
 play=Column(String,index=True)
 role=Column(String,index=True)
 task=Column(String,index=True)
 status=Column(String,index=True)
 changed=Column(Boolean)
 stdout=Column(Text)
