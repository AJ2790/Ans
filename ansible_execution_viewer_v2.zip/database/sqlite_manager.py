from sqlalchemy import create_engine,text
from sqlalchemy.orm import sessionmaker
from config import SQLITE_DB
from database.models import Base
engine=create_engine(f"sqlite:///{SQLITE_DB}")
SessionLocal=sessionmaker(bind=engine)
def init_db(): Base.metadata.create_all(engine)
def purge_job():
 import sqlalchemy
 with engine.begin() as conn: conn.execute(text("DELETE FROM task_events"))
