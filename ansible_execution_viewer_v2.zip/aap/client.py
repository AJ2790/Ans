import requests
class AAPClient:
 def __init__(self,base_url,token):
  self.base_url=base_url
  self.session=requests.Session()
  self.session.headers.update({"Authorization":f"Bearer {token}"})
 def get_job_events(self,job_id):
  page=1
  while True:
   url=f"{self.base_url}/api/v2/jobs/{job_id}/job_events/?page={page}"
   r=self.session.get(url)
   r.raise_for_status()
   d=r.json()
   yield from d.get("results",[])
   if not d.get("next"): break
   page+=1
