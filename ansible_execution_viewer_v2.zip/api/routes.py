from fastapi import APIRouter
router=APIRouter()
@router.get("/health2")
def health2(): return {"ok":True}
