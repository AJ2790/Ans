from database.sqlite_manager import SessionLocal
from database.models import TaskEvent
class QueryService:
 def hosts(self,job_id):
  s=SessionLocal();return [r[0] for r in s.query(TaskEvent.host).filter(TaskEvent.job_id==job_id).distinct().all()]
