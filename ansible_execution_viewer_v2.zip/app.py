from fastapi import FastAPI
from database.sqlite_manager import init_db
from api.routes import router
app=FastAPI(title="Ansible Execution Viewer V2")
init_db()
app.include_router(router)
